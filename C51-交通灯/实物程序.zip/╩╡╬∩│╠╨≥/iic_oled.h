#ifndef __OLED_H
#define __OLED_H	
#include "reg51.h"
#include "iic_oled.h"
#define u8 unsigned char 
#define u16 unsigned int
#define u32 unsigned long  	  

#define Max_Column	128
#define Max_Row		64 

//-----------------OLED�˿ڶ���----------------  
sbit OLED_SCL=P2^1;//SCL
sbit OLED_SDIN=P2^0;//SDA

//OLED�����ú���
void OLED_WR_Byte(unsigned dat,unsigned cmd);    							   		    
void OLED_Init(void);
void OLED_Clear(void);
void OLED_Fill(u8 fill_Data);
void OLED_ShowHZ(u8 x,u8 y,u8 c);
void OLED_Set_Pos(u8 x, u8 y);
#endif  